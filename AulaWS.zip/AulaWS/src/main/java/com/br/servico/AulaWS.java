/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/EjbWebService.java to edit this template
 */
package com.br.servico;

import com.br.dao.Dao;
import com.br.pojo.Aluno;
import com.br.pojo.Curso;
import jakarta.ejb.Stateless;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import java.util.List;

/**
 *
 * @author LeandroFelipedosPass
 */
@WebService(serviceName = "AulaWS")
@Stateless()
public class AulaWS {


    @WebMethod(operationName = "obterAluno")
    public  List<Aluno> obterAluno(@WebParam(name = "matricula_aluno") long matricula) {
        Dao.inserirDados();
        
        return Dao.getAlunos(matricula);
    }
    

    @WebMethod(operationName = "obterCurso")
    public  List<Curso> obterCurso(@WebParam(name = "nome_curso") String curso) {
        Dao.inserirDados();
        
        return Dao.getCursos(curso);
    }
}
