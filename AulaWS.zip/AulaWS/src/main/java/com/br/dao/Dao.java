/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.br.dao;

import com.br.pojo.Aluno;
import com.br.pojo.Curso;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author LeandroFelipedosPass
 */
public class Dao {
    
    public static final List<Aluno> LISTA_ALUNOS = new ArrayList<>();
    public static final List<Curso> LISTA_CURSOS = new ArrayList<>();
    
    public static void inserirDados() {
        Aluno aluno = new Aluno();
        aluno.setMatricula(1111);
        aluno.setNome("Joaquim Mineiro");
        aluno.setIdade(35);
        aluno.setTelefone("31-99999-1111");
        aluno.setEndereco("Rua Dois, 55, Betim/MG");
        
        LISTA_ALUNOS.add(aluno);
        
        Curso curso = new Curso();
        curso.setNomeCurso("WS Java");
        curso.setCargaHoraria(180);
        curso.setProfessor("Michael Jackson");
        curso.setAluno(aluno);
        
        LISTA_CURSOS.add(curso);
        
        Aluno aluno1 = new Aluno();
        aluno1.setMatricula(2222);
        aluno1.setNome("Joel Paulista");
        aluno1.setIdade(35);
        aluno1.setTelefone("31-99999-2222");
        aluno1.setEndereco("Rua Três, 122, São Paulo/SP");
        
        LISTA_ALUNOS.add(aluno1);
        
        Curso curso1 = new Curso();
        curso1.setNomeCurso("WS Java");
        curso1.setCargaHoraria(180);
        curso1.setProfessor("Michael Jackson");
        curso1.setAluno(aluno1);
        
        LISTA_CURSOS.add(curso1);
        
        Aluno aluno2 = new Aluno();
        aluno2.setMatricula(3333);
        aluno2.setNome("Lorena de Janeiro");
        aluno2.setIdade(35);
        aluno2.setTelefone("31-99999-3333");
        aluno2.setEndereco("Rua Um, 30, Rio de Janeiro/RJ");
        
        LISTA_ALUNOS.add(aluno2);
        
        Curso curso2 = new Curso();
        curso2.setNomeCurso("ReactJS");
        curso2.setCargaHoraria(180);
        curso2.setProfessor("Diego");
        curso2.setAluno(aluno2);
        
        LISTA_CURSOS.add(curso2);
        
        Aluno aluno3 = new Aluno();
        aluno3.setMatricula(4444);
        aluno3.setNome("Carlos Santoro");
        aluno3.setIdade(35);
        aluno3.setTelefone("31-99999-4444");
        aluno3.setEndereco("Rua Cinco, 65, Betim/MG");
        
        LISTA_ALUNOS.add(aluno3);
        
        Curso curso3 = new Curso();
        curso3.setNomeCurso("React Native");
        curso3.setCargaHoraria(180);
        curso3.setProfessor("Rodrigo Gonçalves");
        curso3.setAluno(aluno3);
        
        LISTA_CURSOS.add(curso3);
    }
    
    public static List<Aluno> getAlunos(long matricula) {
        if(matricula == 0) {
            return LISTA_ALUNOS;
        } else {
            List<Aluno> retorno = new ArrayList<>();
            
            for(Aluno aluno: LISTA_ALUNOS) {
                if(aluno.getMatricula() == matricula) {
                    retorno.add(aluno);
                    break;
                } else {
                }
            }
            return retorno;
        }
    }
    
    public static List<Curso> getCursos(String nome) {
        if(nome == null || nome.isEmpty()) {
            return LISTA_CURSOS;
        } else {
            List<Curso> retorno = new ArrayList<>();
            
            for(Curso curso: LISTA_CURSOS) {
                if(curso.getNomeCurso().equals(nome)) {
                    retorno.add(curso);
                    break;
                }
            }
            return retorno;
        }
    }
    
    public static void main(String[] args) {
        Dao.inserirDados();
        
        List<Aluno> listaAlunos = Dao.getAlunos(0);
        
        for(Aluno aluno: listaAlunos){
            System.out.println(aluno.getMatricula() + " - " + aluno.getNome());
        }  
        System.out.println("\n---------------------------------------------------------\n");
        
        List<Curso> listaCursos = Dao.getCursos("");
        
        for(Curso curso: listaCursos){
            System.out.println(curso.getNomeCurso() + " - " + curso.getAluno().getNome());
        }        
    }
}
